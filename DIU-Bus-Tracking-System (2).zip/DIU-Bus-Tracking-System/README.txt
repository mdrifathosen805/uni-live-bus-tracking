DIU Bus Tracking System - NetBeans Fixed Project

IMPORTANT:
This project includes a NetBeans custom run action so that Run Project
uses Spring Boot's spring-boot:run instead of NetBeans' default
exec-maven-plugin launcher.

Requirements:
- JDK 17
- Apache NetBeans with Maven support

Run:
1. Extract the ZIP.
2. Open the DIU-Bus-Tracking-System folder in NetBeans.
3. Clean and Build.
4. Right-click the project -> Run.

Expected server:
http://localhost:8081/

If NetBeans still uses exec-maven-plugin:
- Right-click project -> Properties -> Actions.
- Select Run Project.
- Confirm the action uses:
  org.springframework.boot:spring-boot-maven-plugin:run

You can also test outside NetBeans from the project directory:
mvn spring-boot:run

--------------------------------------------------
EMAIL (Gmail) SETUP - powers Forgot Password + Registration codes
--------------------------------------------------
Students can click "Forgot password?" on the login page, and registration
emails a 6-digit code before an account is created. Both use the same
Gmail connection, which you set up ENTIRELY FROM THE BROWSER - no project
files to find or edit, no restart needed:

1. Get a Gmail App Password (one-time, for whichever Gmail account will
   send these emails):
   - Turn on 2-Step Verification: https://myaccount.google.com/security
   - Create an App Password: https://myaccount.google.com/apppasswords
     (App: Mail, Device: Other - "DIU Bus Tracking System") -> Generate -> copy the
     16-character code shown.

2. Run the app, then open in your browser:
       http://localhost:8081/mail-setup
   Enter the Gmail address and paste the App Password, click Save. Done -
   it takes effect immediately, saved in the database.

3. Test it without leaving the browser:
       http://localhost:8081/test-email
   Type an email you can check, click "Send test email". This page shows
   you the EXACT result - success, or the real error message from Gmail
   (e.g. wrong App Password) - so you always know exactly what happened.

Until Gmail is connected, the app still works fully - reset links and
6-digit codes are simply printed to the console/log instead, so you can
test registration/login end-to-end before setting up Gmail.

IMPORTANT: even AFTER Gmail is connected, if a real send ever fails for
any reason (wrong App Password, Gmail rate-limiting, network issue, etc.),
registration and password reset are NOT blocked - the code/link is shown
directly on the page itself, in a red box with the exact reason it
couldn't be emailed, right next to the normal code-entry form. So a Gmail
hiccup can never stop a student from finishing registration or resetting
their password.

SECURITY NOTE: /mail-setup and /test-email don't require login, to make
first-time setup as easy as possible. Once Gmail is connected and working,
remove "/mail-setup" and "/test-email" from the permitAll list in
SecurityConfig.java (or delete MailSetupController/DebugMailController and
their templates) so strangers visiting your site can't see or change your
Gmail sender.

Registration now requires an email address (used only for this feature).

--------------------------------------------------
EMAIL VERIFICATION AT REGISTRATION
--------------------------------------------------
Registration is now 2 steps:
 1. Student fills the register form (Student ID, Name, Email, Password).
    Nothing is saved to the students table yet. A 6-digit code is emailed
    to the Gmail they entered (valid 10 minutes, max 5 wrong tries).
 2. Student enters that code on the next page. Only once the code matches
    does the real account get created and the Approved Student ID get
    marked as used.

This uses the SAME Gmail connection described above (set up once at
/mail-setup). Until that's connected, the 6-digit code is printed to the
console/log instead of emailed, so you can still test registration locally.

--------------------------------------------------
DRIVER SELF-REGISTRATION
--------------------------------------------------
Drivers can now create their own account at /driver/register (link is on
the Driver Login page too) using just their name, phone number, and a
password - no Admin needs to set it up first.

For security, a self-registered driver account starts DISABLED. It won't
be able to log in, and can't be assigned to a bus, until an Admin approves
it: Admin Panel -> Drivers -> find the driver (shows "Disabled") -> click
"Enable". After that, assign them to a bus the same way as before.

--------------------------------------------------
YOUR BUS/DRIVER NAME EDITS ARE SAFE
--------------------------------------------------
The seed data (default routes/buses/drivers) only runs ONCE, the very
first time the app starts with an empty database. After that it never
runs again, so any names you change in Admin -> Buses / Drivers stay
exactly as you set them, even after restarting the app.

--------------------------------------------------
BULK-ADDING APPROVED STUDENT IDS
--------------------------------------------------
Admin Panel -> Approved IDs now has a "Bulk add a range" form for adding
many Student IDs at once instead of one by one.

It generates IDs as batch-dept-serial, e.g. batch 221 + dept 15 +
serial range 1-1000 -> 221-15-001, 221-15-002, ... 221-15-1000 (serials
are zero-padded to at least 3 digits). You can enter several batch codes
separated by commas to do them all in one submit, e.g. for every
batch/year at once:
    221,222,223,231,232,233,241,242,243,251,252,253,261,262,263
with department code 15 and serial range 1 to 1000 - that's 15,000 IDs
added in a single click. IDs already on the list are automatically
skipped, never duplicated, so it's safe to re-run.

The list page now also has search (by partial Student ID) and pagination
(100 per page) since a list this large can't usefully be shown all at
once. There's also a "Remove by prefix" option (under "Undo a bulk add")
in case a batch was entered wrong and needs to be taken back out - e.g.
prefix 221-15- removes just that batch, or 221- removes every batch
starting with 221.

--------------------------------------------------
"Whitelabel Error Page" / 403 after login, register, or any form submit
--------------------------------------------------
This happens when a page was left open in the browser from BEFORE the app
was last restarted (Stop then Run again in NetBeans). Every restart wipes
all logged-in sessions and security tokens, since none of that is saved
to the database - it's normal, not a bug or lost data.

Fix: just reload the page (F5) before submitting the form again. A nicer
error.html now replaces the old blank "Whitelabel Error Page" and
explains this directly on screen, with a link back to the login page.
