package com.university.unibus.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

import java.time.LocalDateTime;

/**
 * A Student ID that the Admin has confirmed belongs to a real university
 * student. Registration is only allowed for IDs that appear here — this is
 * what stops random people from creating accounts with made-up IDs.
 */
@Entity
@Table(name = "approved_student_ids")
public class ApprovedStudentId {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Student ID is required")
    @Column(unique = true)
    private String studentId;

    // Set to true once someone has registered using this ID, so the Admin
    // can see at a glance which approved IDs are still unclaimed.
    private boolean used = false;

    private LocalDateTime addedAt = LocalDateTime.now();

    public ApprovedStudentId() {
    }

    public ApprovedStudentId(String studentId) {
        this.studentId = studentId;
        this.addedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public boolean isUsed() {
        return used;
    }

    public void setUsed(boolean used) {
        this.used = used;
    }

    public LocalDateTime getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(LocalDateTime addedAt) {
        this.addedAt = addedAt;
    }
}
