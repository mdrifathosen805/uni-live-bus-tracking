package com.university.unibus.controller;

import com.university.unibus.dto.BusForm;
import com.university.unibus.model.Bus;
import com.university.unibus.model.Driver;
import com.university.unibus.model.Route;
import com.university.unibus.model.Shift;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.DriverRepository;
import com.university.unibus.repository.RouteRepository;
import com.university.unibus.repository.ShiftRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/buses")
public class AdminBusController {

    private final BusRepository busRepository;
    private final RouteRepository routeRepository;
    private final ShiftRepository shiftRepository;
    private final DriverRepository driverRepository;

    public AdminBusController(BusRepository busRepository, RouteRepository routeRepository,
                               ShiftRepository shiftRepository, DriverRepository driverRepository) {
        this.busRepository = busRepository;
        this.routeRepository = routeRepository;
        this.shiftRepository = shiftRepository;
        this.driverRepository = driverRepository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("buses", busRepository.findAll());
        return "admin/buses";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("busForm", new BusForm());
        addDropdownOptions(model);
        return "admin/bus-form";
    }

    @PostMapping
    public String save(@Valid @ModelAttribute("busForm") BusForm form, BindingResult result, Model model) {
        if (busRepository.findByBusNumber(form.getBusNumber()).isPresent()) {
            result.rejectValue("busNumber", "duplicate", "A bus with this number already exists");
        }
        if (result.hasErrors()) {
            addDropdownOptions(model);
            return "admin/bus-form";
        }

        Bus bus = new Bus(form.getBusNumber(), findRoute(form.getRouteId()), findShift(form.getShiftId()));
        bus.setDriver(hasDriver(form) ? findDriver(form.getDriverId()) : null);
        bus.setActive(form.isActive());
        busRepository.save(bus);
        return "redirect:/admin/buses";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid bus id: " + id));

        BusForm form = new BusForm();
        form.setBusNumber(bus.getBusNumber());
        form.setRouteId(bus.getRoute().getId());
        form.setShiftId(bus.getShift().getId());
        form.setDriverId(bus.getDriver() != null ? bus.getDriver().getId() : null);
        form.setActive(bus.isActive());

        model.addAttribute("busForm", form);
        model.addAttribute("busId", id);
        addDropdownOptions(model);
        return "admin/bus-form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @Valid @ModelAttribute("busForm") BusForm form,
                          BindingResult result, Model model) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid bus id: " + id));

        busRepository.findByBusNumber(form.getBusNumber())
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> result.rejectValue("busNumber", "duplicate", "A bus with this number already exists"));

        if (result.hasErrors()) {
            model.addAttribute("busId", id);
            addDropdownOptions(model);
            return "admin/bus-form";
        }

        bus.setBusNumber(form.getBusNumber());
        bus.setRoute(findRoute(form.getRouteId()));
        bus.setShift(findShift(form.getShiftId()));
        bus.setDriver(hasDriver(form) ? findDriver(form.getDriverId()) : null);
        bus.setActive(form.isActive());
        busRepository.save(bus);
        return "redirect:/admin/buses";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id) {
        busRepository.deleteById(id);
        return "redirect:/admin/buses";
    }

    private void addDropdownOptions(Model model) {
        model.addAttribute("routes", routeRepository.findAll());
        model.addAttribute("shifts", shiftRepository.findAll());
        model.addAttribute("drivers", driverRepository.findAll());
    }

    private boolean hasDriver(BusForm form) {
        return form.getDriverId() != null && form.getDriverId() != 0L;
    }

    private Route findRoute(Long id) {
        return routeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid route id: " + id));
    }

    private Shift findShift(Long id) {
        return shiftRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid shift id: " + id));
    }

    private Driver findDriver(Long id) {
        return driverRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid driver id: " + id));
    }
}
