package com.university.unibus.controller;

import com.university.unibus.model.PasswordResetToken;
import com.university.unibus.model.Student;
import com.university.unibus.repository.PasswordResetTokenRepository;
import com.university.unibus.repository.StudentRepository;
import com.university.unibus.service.EmailService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

/**
 * "Forgot password" flow for students, using their Gmail (or any email)
 * address saved at registration:
 *   1. GET  /forgot-password        -> enter Student ID + email
 *   2. POST /forgot-password        -> if they match, email a one-time reset link
 *   3. GET  /reset-password?token=  -> enter a new password
 *   4. POST /reset-password         -> saves the new (hashed) password
 */
@Controller
public class PasswordResetController {

    private static final int TOKEN_VALID_MINUTES = 30;

    private final StudentRepository studentRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    public PasswordResetController(StudentRepository studentRepository,
                                    PasswordResetTokenRepository tokenRepository,
                                    PasswordEncoder passwordEncoder,
                                    EmailService emailService) {
        this.studentRepository = studentRepository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    @GetMapping("/forgot-password")
    public String forgotPasswordForm() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String forgotPasswordSubmit(@RequestParam String studentId,
                                        @RequestParam String email,
                                        HttpServletRequest request,
                                        Model model) {
        Optional<Student> studentOpt = studentRepository.findByStudentId(studentId.trim());

        // Only send an email if the Student ID exists AND the email matches what's on file.
        // Either way we show the SAME message, so this page can't be used to check
        // which Student IDs are registered or which email is attached to one.
        if (studentOpt.isPresent()) {
            Student student = studentOpt.get();
            if (student.getEmail() != null && student.getEmail().equalsIgnoreCase(email.trim())) {
                String token = UUID.randomUUID().toString();
                tokenRepository.save(new PasswordResetToken(
                        token, student, LocalDateTime.now().plusMinutes(TOKEN_VALID_MINUTES)));

                String resetLink = ServletUriComponentsBuilder.fromRequestUri(request)
                        .replacePath("/reset-password")
                        .replaceQuery("token=" + token)
                        .build().toUriString();

                EmailService.SendResult sendResult = emailService.sendPasswordResetEmail(
                        student.getEmail(), student.getName(), resetLink);
                if (!sendResult.success()) {
                    model.addAttribute("mailFailed", true);
                    model.addAttribute("devLink", resetLink);
                    model.addAttribute("mailErrorDetail", sendResult.detail());
                }
            }
        }

        model.addAttribute("submitted", true);
        return "forgot-password";
    }

    @GetMapping("/reset-password")
    public String resetPasswordForm(@RequestParam String token, Model model) {
        Optional<PasswordResetToken> tokenOpt = tokenRepository.findByToken(token);
        if (tokenOpt.isEmpty() || tokenOpt.get().isUsed() || tokenOpt.get().isExpired()) {
            model.addAttribute("invalid", true);
            return "reset-password";
        }
        model.addAttribute("token", token);
        return "reset-password";
    }

    @PostMapping("/reset-password")
    public String resetPasswordSubmit(@RequestParam String token,
                                       @RequestParam String password,
                                       @RequestParam String confirmPassword,
                                       Model model) {
        Optional<PasswordResetToken> tokenOpt = tokenRepository.findByToken(token);
        if (tokenOpt.isEmpty() || tokenOpt.get().isUsed() || tokenOpt.get().isExpired()) {
            model.addAttribute("invalid", true);
            return "reset-password";
        }

        if (!password.equals(confirmPassword)) {
            model.addAttribute("token", token);
            model.addAttribute("error", "Passwords do not match.");
            return "reset-password";
        }
        if (password.length() < 6) {
            model.addAttribute("token", token);
            model.addAttribute("error", "Password must be at least 6 characters.");
            return "reset-password";
        }

        PasswordResetToken resetToken = tokenOpt.get();
        Student student = resetToken.getStudent();
        student.setPassword(passwordEncoder.encode(password));
        studentRepository.save(student);

        resetToken.setUsed(true);
        tokenRepository.save(resetToken);

        return "redirect:/login?resetSuccess";
    }
}
