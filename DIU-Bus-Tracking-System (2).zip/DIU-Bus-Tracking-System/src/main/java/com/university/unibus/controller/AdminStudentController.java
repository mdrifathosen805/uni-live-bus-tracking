package com.university.unibus.controller;

import com.university.unibus.model.Student;
import com.university.unibus.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/students")
public class AdminStudentController {

    private final StudentRepository studentRepository;

    public AdminStudentController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping
    public String list(@RequestParam(required = false) String search, Model model) {
        List<Student> students = studentRepository.findAll();
        if (search != null && !search.isBlank()) {
            String query = search.toLowerCase();
            students = students.stream()
                    .filter(s -> s.getStudentId().toLowerCase().contains(query)
                            || s.getName().toLowerCase().contains(query))
                    .toList();
        }
        model.addAttribute("students", students);
        model.addAttribute("search", search);
        return "admin/students";
    }

    @PostMapping("/{id}/approve")
    public String approve(@PathVariable Long id) {
        Student student = find(id);
        student.setApproved(true);
        studentRepository.save(student);
        return "redirect:/admin/students";
    }

    @PostMapping("/{id}/block")
    public String block(@PathVariable Long id) {
        Student student = find(id);
        student.setBlocked(true);
        studentRepository.save(student);
        return "redirect:/admin/students";
    }

    @PostMapping("/{id}/unblock")
    public String unblock(@PathVariable Long id) {
        Student student = find(id);
        student.setBlocked(false);
        studentRepository.save(student);
        return "redirect:/admin/students";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id) {
        studentRepository.deleteById(id);
        return "redirect:/admin/students";
    }

    private Student find(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid student id: " + id));
    }
}
