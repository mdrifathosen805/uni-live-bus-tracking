package com.university.unibus.controller;

import com.university.unibus.model.BusStop;
import com.university.unibus.model.Route;
import com.university.unibus.repository.BusStopRepository;
import com.university.unibus.repository.RouteRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/routes")
public class AdminRouteController {

    private final RouteRepository routeRepository;
    private final BusStopRepository busStopRepository;

    public AdminRouteController(RouteRepository routeRepository, BusStopRepository busStopRepository) {
        this.routeRepository = routeRepository;
        this.busStopRepository = busStopRepository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("routes", routeRepository.findAllWithStops());
        return "admin/routes";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("route", new Route());
        return "admin/route-form";
    }

    @PostMapping
    public String save(@Valid @ModelAttribute("route") Route route, BindingResult result) {
        if (result.hasErrors()) {
            return "admin/route-form";
        }
        routeRepository.save(route);
        return "redirect:/admin/routes";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid route id: " + id));
        model.addAttribute("route", route);
        model.addAttribute("stops", busStopRepository.findByRouteOrderBySequenceOrderAsc(route));
        model.addAttribute("newStop", new BusStop());
        return "admin/route-edit";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @Valid @ModelAttribute("route") Route routeForm, BindingResult result) {
        if (result.hasErrors()) {
            return "admin/route-form";
        }
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid route id: " + id));
        route.setName(routeForm.getName());
        route.setDescription(routeForm.getDescription());
        routeRepository.save(route);
        return "redirect:/admin/routes/" + id + "/edit";
    }

    @PostMapping("/{id}/toggle-active")
    public String toggleActive(@PathVariable Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid route id: " + id));
        route.setActive(!route.isActive());
        routeRepository.save(route);
        return "redirect:/admin/routes";
    }

    // ---- Stops nested under a route ----

    @PostMapping("/{routeId}/stops")
    public String addStop(@PathVariable Long routeId,
                           @RequestParam String name,
                           @RequestParam int sequenceOrder,
                           @RequestParam(required = false) Double latitude,
                           @RequestParam(required = false) Double longitude) {
        Route route = routeRepository.findById(routeId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid route id: " + routeId));
        BusStop stop = new BusStop(name, sequenceOrder, route);
        stop.setLatitude(latitude);
        stop.setLongitude(longitude);
        busStopRepository.save(stop);
        return "redirect:/admin/routes/" + routeId + "/edit";
    }

    @GetMapping("/stops/{stopId}/edit")
    public String editStopForm(@PathVariable Long stopId, Model model) {
        BusStop stop = busStopRepository.findById(stopId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stop id: " + stopId));
        model.addAttribute("stop", stop);
        return "admin/stop-form";
    }

    @PostMapping("/stops/{stopId}")
    public String updateStop(@PathVariable Long stopId,
                              @RequestParam String name,
                              @RequestParam int sequenceOrder,
                              @RequestParam(required = false) Double latitude,
                              @RequestParam(required = false) Double longitude) {
        BusStop stop = busStopRepository.findById(stopId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stop id: " + stopId));
        stop.setName(name);
        stop.setSequenceOrder(sequenceOrder);
        stop.setLatitude(latitude);
        stop.setLongitude(longitude);
        busStopRepository.save(stop);
        return "redirect:/admin/routes/" + stop.getRoute().getId() + "/edit";
    }

    @PostMapping("/stops/{stopId}/delete")
    public String deleteStop(@PathVariable Long stopId) {
        BusStop stop = busStopRepository.findById(stopId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stop id: " + stopId));
        Long routeId = stop.getRoute().getId();
        busStopRepository.delete(stop);
        return "redirect:/admin/routes/" + routeId + "/edit";
    }
}
