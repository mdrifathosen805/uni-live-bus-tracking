package com.university.unibus.controller;

import com.university.unibus.model.Bus;
import com.university.unibus.model.Driver;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.DriverRepository;
import jakarta.validation.Valid;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/admin/drivers")
public class AdminDriverController {

    private final DriverRepository driverRepository;
    private final BusRepository busRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminDriverController(DriverRepository driverRepository, BusRepository busRepository,
                                  PasswordEncoder passwordEncoder) {
        this.driverRepository = driverRepository;
        this.busRepository = busRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String list(Model model) {
        var drivers = driverRepository.findAll();
        Map<Long, String> assignedBus = new HashMap<>();
        for (Driver driver : drivers) {
            busRepository.findByDriver(driver).ifPresent(bus -> assignedBus.put(driver.getId(), bus.getBusNumber()));
        }
        model.addAttribute("drivers", drivers);
        model.addAttribute("assignedBus", assignedBus);
        return "admin/drivers";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("driver", new Driver());
        return "admin/driver-form";
    }

    @PostMapping
    public String save(@Valid @ModelAttribute("driver") Driver driver, BindingResult result) {
        if (driverRepository.findByPhone(driver.getPhone()).isPresent()) {
            result.rejectValue("phone", "duplicate", "A driver with this phone number already exists");
        }
        if (result.hasErrors()) {
            return "admin/driver-form";
        }
        // Real driver login (Phase 5) will replace this with a proper password reset flow.
        driver.setPassword(passwordEncoder.encode(
                driver.getPassword() != null && !driver.getPassword().isBlank() ? driver.getPassword() : "changeme"));
        driverRepository.save(driver);
        return "redirect:/admin/drivers";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Driver driver = driverRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid driver id: " + id));
        model.addAttribute("driver", driver);
        return "admin/driver-form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @Valid @ModelAttribute("driver") Driver form,
                          BindingResult result) {
        Driver driver = driverRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid driver id: " + id));

        driverRepository.findByPhone(form.getPhone())
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> result.rejectValue("phone", "duplicate", "A driver with this phone number already exists"));

        if (result.hasErrors()) {
            return "admin/driver-form";
        }

        driver.setName(form.getName());
        driver.setPhone(form.getPhone());
        driverRepository.save(driver);
        return "redirect:/admin/drivers";
    }

    @PostMapping("/{id}/toggle-active")
    public String toggleActive(@PathVariable Long id) {
        Driver driver = driverRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid driver id: " + id));
        driver.setActive(!driver.isActive());
        driverRepository.save(driver);
        return "redirect:/admin/drivers";
    }
}
