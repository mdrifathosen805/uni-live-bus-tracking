package com.university.unibus.controller;

import com.university.unibus.model.Shift;
import com.university.unibus.repository.ShiftRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/shifts")
public class AdminShiftController {

    private final ShiftRepository shiftRepository;

    public AdminShiftController(ShiftRepository shiftRepository) {
        this.shiftRepository = shiftRepository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("shifts", shiftRepository.findAll());
        return "admin/shifts";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("shift", new Shift());
        return "admin/shift-form";
    }

    @PostMapping
    public String save(@Valid @ModelAttribute("shift") Shift shift, BindingResult result) {
        if (result.hasErrors()) {
            return "admin/shift-form";
        }
        shiftRepository.save(shift);
        return "redirect:/admin/shifts";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Shift shift = shiftRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid shift id: " + id));
        model.addAttribute("shift", shift);
        return "admin/shift-form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @Valid @ModelAttribute("shift") Shift shiftForm, BindingResult result) {
        if (result.hasErrors()) {
            return "admin/shift-form";
        }
        Shift shift = shiftRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid shift id: " + id));
        shift.setName(shiftForm.getName());
        shift.setStartTime(shiftForm.getStartTime());
        shiftRepository.save(shift);
        return "redirect:/admin/shifts";
    }
}
