package com.university.unibus.controller;

import com.university.unibus.dto.DriverRegistrationForm;
import com.university.unibus.model.Bus;
import com.university.unibus.model.Driver;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.DriverRepository;
import com.university.unibus.service.BusStatusService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

/**
 * Driver login is handled by hand, the same way AdminController does it,
 * because a Spring Security formLogin chain can only be wired up once per
 * app and the student login already uses that slot. Phone number is the
 * driver's username.
 *
 * Drivers can also create their own account with just name + phone +
 * password (see /driver/register below). A self-registered account starts
 * INACTIVE - it can't log in until an Admin approves it from the Admin
 * Panel (Driver Management), the same switch used for "disable driver".
 * This stops a random person from registering as a driver and getting
 * access on their own.
 */
@Controller
@RequestMapping("/driver")
public class DriverController {

    private final DriverRepository driverRepository;
    private final BusRepository busRepository;
    private final PasswordEncoder passwordEncoder;
    private final BusStatusService busStatusService;

    public DriverController(DriverRepository driverRepository, BusRepository busRepository,
                             PasswordEncoder passwordEncoder, BusStatusService busStatusService) {
        this.driverRepository = driverRepository;
        this.busRepository = busRepository;
        this.passwordEncoder = passwordEncoder;
        this.busStatusService = busStatusService;
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("form", new DriverRegistrationForm());
        return "driver-register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("form") DriverRegistrationForm form, BindingResult result) {
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword", "mismatch", "Passwords do not match");
        }
        if (driverRepository.findByPhone(form.getPhone()).isPresent()) {
            result.rejectValue("phone", "duplicate", "An account already exists for this phone number");
        }
        if (form.getPassword() != null && form.getPassword().length() < 6) {
            result.rejectValue("password", "tooShort", "Password must be at least 6 characters");
        }

        if (result.hasErrors()) {
            return "driver-register";
        }

        Driver driver = new Driver(form.getName().trim(), form.getPhone().trim(),
                passwordEncoder.encode(form.getPassword()));
        driver.setActive(false); // Admin must approve/activate before this driver can log in or get a bus assigned
        driverRepository.save(driver);

        return "redirect:/driver/login?registered";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "driver-login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String phone,
                         @RequestParam String password,
                         HttpServletRequest request) {

        Optional<Driver> driverOpt = driverRepository.findByPhone(phone);

        boolean passwordOk = driverOpt.isPresent() && passwordEncoder.matches(password, driverOpt.get().getPassword());
        boolean activeOk = driverOpt.isPresent() && driverOpt.get().isActive();

        if (driverOpt.isEmpty() || !passwordOk || !activeOk) {
            // Vague on purpose - same reasoning as the admin login: don't reveal which
            // field was wrong or whether the account exists but was disabled/not yet approved.
            return "redirect:/driver/login?error";
        }

        Driver driver = driverOpt.get();
        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                driver.getPhone(), null, List.of(new SimpleGrantedAuthority("ROLE_DRIVER")));

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authToken);
        SecurityContextHolder.setContext(context);
        request.getSession(true).setAttribute("SPRING_SECURITY_CONTEXT", context);

        return "redirect:/driver/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model) {
        Driver driver = driverRepository.findByPhone(principal.getName())
                .orElseThrow(() -> new IllegalStateException("Logged-in driver not found: " + principal.getName()));
        Bus bus = busRepository.findByDriver(driver).orElse(null);

        model.addAttribute("driver", driver);
        model.addAttribute("bus", bus);
        return "driver-dashboard";
    }

    @PostMapping("/trip/start")
    public String startTrip(Principal principal) {
        Bus bus = requireOwnBus(principal);
        bus.setTripActive(true);
        busStatusService.onTripStart(bus);
        busRepository.save(bus);
        return "redirect:/driver/dashboard";
    }

    @PostMapping("/trip/end")
    public String endTrip(Principal principal) {
        Bus bus = requireOwnBus(principal);
        bus.setTripActive(false);
        busStatusService.onTripEnd(bus);
        busRepository.save(bus);
        return "redirect:/driver/dashboard";
    }

    private Bus requireOwnBus(Principal principal) {
        Driver driver = driverRepository.findByPhone(principal.getName())
                .orElseThrow(() -> new IllegalStateException("Logged-in driver not found: " + principal.getName()));
        return busRepository.findByDriver(driver)
                .orElseThrow(() -> new IllegalStateException("No bus is assigned to this driver yet. Contact the Admin."));
    }
}
