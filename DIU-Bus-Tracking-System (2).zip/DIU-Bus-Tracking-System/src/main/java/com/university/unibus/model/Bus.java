package com.university.unibus.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

import java.time.LocalDateTime;

@Entity
@Table(name = "buses")
public class Bus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Bus number is required")
    @Column(unique = true)
    private String busNumber; // e.g. "Bus-01"

    @ManyToOne
    @JoinColumn(name = "route_id", nullable = false)
    private Route route;

    @ManyToOne
    @JoinColumn(name = "shift_id", nullable = false)
    private Shift shift;

    @OneToOne
    @JoinColumn(name = "driver_id", unique = true)
    private Driver driver; // nullable — a bus may not have a driver assigned yet

    private boolean active = true;

    // --- Live GPS fields (populated starting Phase 6-8; safe to leave null until then) ---
    private String currentStopName;
    private Double currentLatitude;
    private Double currentLongitude;
    private Double currentSpeed;
    private LocalDateTime lastUpdated;

    // True while the assigned driver has pressed "Start Trip" and not yet "End Trip".
    // The student-facing map/status only trusts location data while this is true.
    private boolean tripActive = false;

    // Index (0-based) into route.getStops() of the last stop this bus was detected
    // arriving at during the CURRENT trip. Null = trip not started / no stop reached yet.
    // This is what powers the "on the way / at stop / passed your stop" status logic.
    private Integer currentStopIndex;

    public Bus() {
    }

    public Bus(String busNumber, Route route, Shift shift) {
        this.busNumber = busNumber;
        this.route = route;
        this.shift = shift;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCurrentStopName() {
        return currentStopName;
    }

    public void setCurrentStopName(String currentStopName) {
        this.currentStopName = currentStopName;
    }

    public Double getCurrentLatitude() {
        return currentLatitude;
    }

    public void setCurrentLatitude(Double currentLatitude) {
        this.currentLatitude = currentLatitude;
    }

    public Double getCurrentLongitude() {
        return currentLongitude;
    }

    public void setCurrentLongitude(Double currentLongitude) {
        this.currentLongitude = currentLongitude;
    }

    public Double getCurrentSpeed() {
        return currentSpeed;
    }

    public void setCurrentSpeed(Double currentSpeed) {
        this.currentSpeed = currentSpeed;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public boolean isTripActive() {
        return tripActive;
    }

    public void setTripActive(boolean tripActive) {
        this.tripActive = tripActive;
    }

    public Integer getCurrentStopIndex() {
        return currentStopIndex;
    }

    public void setCurrentStopIndex(Integer currentStopIndex) {
        this.currentStopIndex = currentStopIndex;
    }
}
