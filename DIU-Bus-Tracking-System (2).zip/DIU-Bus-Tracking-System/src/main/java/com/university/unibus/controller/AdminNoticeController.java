package com.university.unibus.controller;

import com.university.unibus.model.Notice;
import com.university.unibus.repository.NoticeRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/notices")
public class AdminNoticeController {

    private final NoticeRepository noticeRepository;

    public AdminNoticeController(NoticeRepository noticeRepository) {
        this.noticeRepository = noticeRepository;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("notices", noticeRepository.findAll());
        return "admin/notices";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("notice", new Notice());
        model.addAttribute("noticeTypes", com.university.unibus.model.NoticeType.values());
        return "admin/notice-form";
    }

    @PostMapping
    public String save(@Valid @ModelAttribute("notice") Notice notice, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("noticeTypes", com.university.unibus.model.NoticeType.values());
            return "admin/notice-form";
        }
        noticeRepository.save(notice);
        return "redirect:/admin/notices";
    }

    @PostMapping("/{id}/toggle-active")
    public String toggleActive(@PathVariable Long id) {
        Notice notice = noticeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid notice id: " + id));
        notice.setActive(!notice.isActive());
        noticeRepository.save(notice);
        return "redirect:/admin/notices";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id) {
        noticeRepository.deleteById(id);
        return "redirect:/admin/notices";
    }
}
