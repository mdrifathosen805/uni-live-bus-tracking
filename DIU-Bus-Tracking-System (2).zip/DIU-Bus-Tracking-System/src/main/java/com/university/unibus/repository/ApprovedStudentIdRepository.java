package com.university.unibus.repository;

import com.university.unibus.model.ApprovedStudentId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ApprovedStudentIdRepository extends JpaRepository<ApprovedStudentId, Long> {
    Optional<ApprovedStudentId> findByStudentId(String studentId);

    Page<ApprovedStudentId> findByStudentIdContainingIgnoreCase(String query, Pageable pageable);

    List<ApprovedStudentId> findByStudentIdStartingWith(String prefix);

    long countByUsedTrue();
}
