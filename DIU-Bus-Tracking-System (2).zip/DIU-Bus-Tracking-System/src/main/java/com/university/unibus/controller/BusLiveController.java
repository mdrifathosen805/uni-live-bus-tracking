package com.university.unibus.controller;

import com.university.unibus.model.Bus;
import com.university.unibus.model.BusStop;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.BusStopRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Phase 8: read-only JSON the Leaflet map (student dashboard, admin buses
 * page) polls every few seconds to draw/move bus markers and stop pins.
 * Any logged-in user (student/driver/admin) can call this — bus location
 * on its own isn't sensitive, and SecurityConfig already requires login
 * for anything outside the public pages.
 */
@RestController
@RequestMapping("/api")
public class BusLiveController {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("hh:mm:ss a");

    private final BusRepository busRepository;
    private final BusStopRepository busStopRepository;

    public BusLiveController(BusRepository busRepository, BusStopRepository busStopRepository) {
        this.busRepository = busRepository;
        this.busStopRepository = busStopRepository;
    }

    @GetMapping("/buses/live")
    public List<Map<String, Object>> liveBuses() {
        return busRepository.findAll().stream()
                .filter(Bus::isActive)
                .map(this::toJson)
                .collect(Collectors.toList());
    }

    @GetMapping("/stops")
    public List<Map<String, Object>> allStops() {
        return busStopRepository.findAll().stream()
                .filter(s -> s.getLatitude() != null && s.getLongitude() != null)
                .map(this::toJson)
                .collect(Collectors.toList());
    }

    private Map<String, Object> toJson(Bus bus) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", bus.getId());
        m.put("busNumber", bus.getBusNumber());
        m.put("route", bus.getRoute().getName());
        m.put("shift", bus.getShift().getName());
        m.put("tripActive", bus.isTripActive());
        m.put("latitude", bus.getCurrentLatitude());
        m.put("longitude", bus.getCurrentLongitude());
        m.put("speed", bus.getCurrentSpeed());
        m.put("lastUpdated", bus.getLastUpdated() != null ? bus.getLastUpdated().format(TIME_FORMAT) : null);
        return m;
    }

    private Map<String, Object> toJson(BusStop stop) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", stop.getId());
        m.put("name", stop.getName());
        m.put("route", stop.getRoute().getName());
        m.put("sequenceOrder", stop.getSequenceOrder());
        m.put("latitude", stop.getLatitude());
        m.put("longitude", stop.getLongitude());
        return m;
    }
}
