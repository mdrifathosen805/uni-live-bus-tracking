package com.university.unibus.repository;

import com.university.unibus.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RouteRepository extends JpaRepository<Route, Long> {
    Optional<Route> findByName(String name);

    // route.stops is a LAZY collection. Any page that needs a route's stops
    // (student dashboard's stop picker, the public overview page, the admin
    // routes list) must load them together with the route in one query like
    // this - otherwise touching route.getStops() later (e.g. in the Thymeleaf
    // template) can throw a LazyInitializationException -> 500 error, because
    // by the time the template renders, the original DB session may already
    // be closed.
    @Query("SELECT DISTINCT r FROM Route r LEFT JOIN FETCH r.stops ORDER BY r.name")
    List<Route> findAllWithStops();
}
