package com.university.unibus.repository;

import com.university.unibus.model.BusStop;
import com.university.unibus.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BusStopRepository extends JpaRepository<BusStop, Long> {
    List<BusStop> findByRouteOrderBySequenceOrderAsc(Route route);
}
