package com.university.unibus.service;

import com.university.unibus.model.MailSettings;
import com.university.unibus.repository.MailSettingsRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Properties;

/**
 * Sends emails through Gmail. The Gmail address + App Password can come
 * from EITHER of two places, checked in this order:
 *   1. The database (set from the browser at /mail-setup - no file editing,
 *      no restart needed, works immediately after clicking Save).
 *   2. spring.mail.username / spring.mail.password in application.properties
 *      (used only if nothing has been saved at /mail-setup yet).
 * Either way, if no credentials are available yet, we just print the code
 * or link to the console instead of crashing.
 */
@Service
public class EmailService {

    private final MailSettingsRepository mailSettingsRepository;
    private final String propertiesUsername;
    private final String propertiesPassword;

    public EmailService(MailSettingsRepository mailSettingsRepository,
                         @Value("${spring.mail.username:}") String propertiesUsername,
                         @Value("${spring.mail.password:}") String propertiesPassword) {
        this.mailSettingsRepository = mailSettingsRepository;
        this.propertiesUsername = propertiesUsername;
        this.propertiesPassword = propertiesPassword;
    }

    /** Resolves the Gmail address currently in effect (DB first, then application.properties). Blank if none set yet. */
    public String getFromAddress() {
        return resolveUsername();
    }

    public boolean isMailEnabled() {
        String u = resolveUsername();
        String p = resolvePassword();
        return u != null && !u.isBlank() && p != null && !p.isBlank();
    }

    private String resolveUsername() {
        Optional<MailSettings> s = mailSettingsRepository.findById(1L);
        if (s.isPresent() && s.get().getGmailUsername() != null && !s.get().getGmailUsername().isBlank()) {
            return s.get().getGmailUsername().trim();
        }
        return propertiesUsername;
    }

    private String resolvePassword() {
        Optional<MailSettings> s = mailSettingsRepository.findById(1L);
        if (s.isPresent() && s.get().getGmailAppPassword() != null && !s.get().getGmailAppPassword().isBlank()) {
            return s.get().getGmailAppPassword().trim();
        }
        return propertiesPassword;
    }

    /** Saves/updates the Gmail address + App Password from the /mail-setup form. Spaces in the App Password are stripped. */
    public void saveCredentials(String gmailUsername, String gmailAppPassword) {
        MailSettings settings = mailSettingsRepository.findById(1L).orElseGet(MailSettings::new);
        settings.setId(1L);
        settings.setGmailUsername(gmailUsername == null ? null : gmailUsername.trim());
        settings.setGmailAppPassword(gmailAppPassword == null ? null : gmailAppPassword.replace(" ", "").trim());
        mailSettingsRepository.save(settings);
    }

    private JavaMailSenderImpl buildSender(String username, String password) {
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost("smtp.gmail.com");
        sender.setPort(587);
        sender.setUsername(username);
        sender.setPassword(password);
        Properties props = sender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.connectiontimeout", "10000");
        props.put("mail.smtp.timeout", "10000");
        props.put("mail.smtp.writetimeout", "10000");
        return sender;
    }

    /** Used by /test-email and /mail-setup so you can check the Gmail connection from a browser, with the real error shown on screen. */
    public SendResult sendTestEmail(String toEmail) {
        String username = resolveUsername();
        String password = resolvePassword();
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            return new SendResult(false, "Mail is OFF: no Gmail address/App Password saved yet. "
                    + "Go to /mail-setup and save them first.");
        }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(username);
            message.setTo(toEmail);
            message.setSubject("DIU Bus Tracking System - Test Email");
            message.setText("If you can read this, Gmail sending is working correctly for DIU Bus Tracking System.");
            buildSender(username, password).send(message);
            return new SendResult(true, "Sent successfully from " + username + " to " + toEmail
                    + ". Check that inbox (and Spam folder).");
        } catch (Exception e) {
            String cause = (e.getCause() != null) ? e.getCause().toString() : "none";
            return new SendResult(false, e + " | cause: " + cause);
        }
    }

    public record SendResult(boolean success, String detail) {
    }

    /** Always succeeds from the caller's point of view - if real sending fails, the SendResult still carries the code so the page can show it as a fallback. */
    public SendResult sendVerificationCode(String toEmail, String studentName, String code) {
        String username = resolveUsername();
        String password = resolvePassword();
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            System.out.println("[DIU Bus Tracking System] >>> Registration verification code for " + toEmail + ": " + code + " <<<");
            return new SendResult(false, "Gmail is not connected yet (nothing saved at /mail-setup).");
        }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(username);
            message.setTo(toEmail);
            message.setSubject("DIU Bus Tracking System - Verify your email (code: " + code + ")");
            message.setText(
                    "Hi " + studentName + ",\n\n" +
                    "Your DIU Bus Tracking System verification code is:\n\n" +
                    "    " + code + "\n\n" +
                    "Enter this code on the registration page to finish creating your account. " +
                    "This code expires in 10 minutes.\n\n" +
                    "If you did not try to register, you can ignore this email.\n\n" +
                    "- DIU Bus Tracking System"
            );
            buildSender(username, password).send(message);
            System.out.println("[DIU Bus Tracking System] Verification email sent to " + toEmail);
            return new SendResult(true, "Sent to " + toEmail);
        } catch (Exception e) {
            String cause = (e.getCause() != null) ? e.getCause().toString() : e.toString();
            System.err.println("[DIU Bus Tracking System] FAILED to send verification email to " + toEmail + ": " + e);
            System.out.println("[DIU Bus Tracking System] >>> Fallback - verification code for " + toEmail + ": " + code + " <<<");
            return new SendResult(false, cause);
        }
    }

    /** Always succeeds from the caller's point of view - if real sending fails, the SendResult still carries the link so the page can show it as a fallback. */
    public SendResult sendPasswordResetEmail(String toEmail, String studentName, String resetLink) {
        String username = resolveUsername();
        String password = resolvePassword();
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            System.out.println("[DIU Bus Tracking System] >>> Password reset link for " + toEmail + ": " + resetLink + " <<<");
            return new SendResult(false, "Gmail is not connected yet (nothing saved at /mail-setup).");
        }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(username);
            message.setTo(toEmail);
            message.setSubject("DIU Bus Tracking System - Reset your password");
            message.setText(
                    "Hi " + studentName + ",\n\n" +
                    "We received a request to reset your DIU Bus Tracking System password.\n\n" +
                    "Click the link below to set a new password. This link expires in 30 minutes:\n" +
                    resetLink + "\n\n" +
                    "If you did not request this, you can safely ignore this email - your password will not change.\n\n" +
                    "- DIU Bus Tracking System"
            );
            buildSender(username, password).send(message);
            System.out.println("[DIU Bus Tracking System] Password reset email sent to " + toEmail);
            return new SendResult(true, "Sent to " + toEmail);
        } catch (Exception e) {
            String cause = (e.getCause() != null) ? e.getCause().toString() : e.toString();
            System.err.println("[DIU Bus Tracking System] FAILED to send password reset email to " + toEmail + ": " + e);
            System.out.println("[DIU Bus Tracking System] >>> Fallback - password reset link for " + toEmail + ": " + resetLink + " <<<");
            return new SendResult(false, cause);
        }
    }
}
