package com.university.unibus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniBusApplication {

    public static void main(String[] args) {
        SpringApplication.run(UniBusApplication.class, args);
    }
}
