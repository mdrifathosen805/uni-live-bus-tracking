package com.university.unibus.model;

public enum NoticeType {
    DELAY,
    ROUTE_CHANGE,
    CANCELLATION,
    EMERGENCY,
    SCHEDULE_CHANGE
}
