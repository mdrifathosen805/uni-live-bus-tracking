package com.university.unibus.security;

import com.university.unibus.model.Student;
import com.university.unibus.repository.StudentRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Authenticates students by their Student ID. A student who has registered
 * but not yet been approved by the Admin is treated as "disabled" — Spring
 * Security will reject the login with a clear reason before even checking
 * the password. Blocked students are treated as "locked" the same way.
 */
@Service
public class StudentUserDetailsService implements UserDetailsService {

    private final StudentRepository studentRepository;

    public StudentUserDetailsService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String studentId) throws UsernameNotFoundException {
        Student student = studentRepository.findByStudentId(studentId)
                .orElseThrow(() -> new UsernameNotFoundException("No account found for Student ID: " + studentId));

        return User.builder()
                .username(student.getStudentId())
                .password(student.getPassword())
                .authorities("ROLE_STUDENT")
                .disabled(!student.isApproved())
                .accountLocked(student.isBlocked())
                .build();
    }
}
