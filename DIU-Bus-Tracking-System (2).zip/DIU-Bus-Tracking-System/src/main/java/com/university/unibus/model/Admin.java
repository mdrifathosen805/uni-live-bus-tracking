package com.university.unibus.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "admins")
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Admin ID is required")
    @Column(unique = true)
    private String adminId;

    // NOTE: plain text for now — real password + secret code hashing (BCrypt)
    // is added in Phase 3 when we implement Admin authentication.
    private String password;
    private String secretCode;

    public Admin() {
    }

    public Admin(String adminId, String password, String secretCode) {
        this.adminId = adminId;
        this.password = password;
        this.secretCode = secretCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSecretCode() {
        return secretCode;
    }

    public void setSecretCode(String secretCode) {
        this.secretCode = secretCode;
    }
}
