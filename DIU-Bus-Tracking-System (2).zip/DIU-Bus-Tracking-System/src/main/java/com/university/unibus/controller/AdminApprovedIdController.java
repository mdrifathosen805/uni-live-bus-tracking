package com.university.unibus.controller;

import com.university.unibus.model.ApprovedStudentId;
import com.university.unibus.repository.ApprovedStudentIdRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin/approved-ids")
public class AdminApprovedIdController {

    private static final int PAGE_SIZE = 100;

    private final ApprovedStudentIdRepository approvedStudentIdRepository;

    public AdminApprovedIdController(ApprovedStudentIdRepository approvedStudentIdRepository) {
        this.approvedStudentIdRepository = approvedStudentIdRepository;
    }

    @GetMapping
    public String list(@RequestParam(required = false) String q,
                        @RequestParam(defaultValue = "0") int page,
                        Model model) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), PAGE_SIZE, Sort.by("studentId"));
        Page<ApprovedStudentId> results = (q != null && !q.isBlank())
                ? approvedStudentIdRepository.findByStudentIdContainingIgnoreCase(q.trim(), pageable)
                : approvedStudentIdRepository.findAll(pageable);

        model.addAttribute("ids", results.getContent());
        model.addAttribute("resultPage", results);
        model.addAttribute("q", q);
        model.addAttribute("totalCount", approvedStudentIdRepository.count());
        model.addAttribute("registeredCount", approvedStudentIdRepository.countByUsedTrue());
        return "admin/approved-ids";
    }

    @PostMapping
    public String add(@RequestParam String studentId, RedirectAttributes redirectAttributes) {
        studentId = studentId.trim();
        if (!studentId.isEmpty() && approvedStudentIdRepository.findByStudentId(studentId).isEmpty()) {
            approvedStudentIdRepository.save(new ApprovedStudentId(studentId));
        }
        return "redirect:/admin/approved-ids";
    }

    /**
     * Generates and adds many Student IDs at once in the pattern
     * {batchCode}-{deptCode}-{serial}, e.g. batch "221", dept "15", serial 1..1000
     * -> 221-15-001, 221-15-002, ... 221-15-1000. Several comma-separated batch
     * codes can be filled in together (e.g. "221,222,223,231,232,233"). Serial
     * numbers are zero-padded to at least 3 digits (1 -> 001, 1000 -> 1000).
     * IDs that already exist on the approved list are skipped, not duplicated.
     */
    @PostMapping("/bulk-add")
    public String bulkAdd(@RequestParam String batchCodes,
                           @RequestParam String deptCode,
                           @RequestParam int startSerial,
                           @RequestParam int endSerial,
                           RedirectAttributes redirectAttributes) {
        deptCode = deptCode.trim();
        if (startSerial < 1) startSerial = 1;
        if (endSerial < startSerial) endSerial = startSerial;
        if (endSerial - startSerial > 20000) endSerial = startSerial + 20000; // sanity cap per submit

        List<String> batches = List.of(batchCodes.split(",")).stream()
                .map(String::trim)
                .filter(b -> !b.isEmpty())
                .toList();

        Set<String> existing = approvedStudentIdRepository.findAll().stream()
                .map(ApprovedStudentId::getStudentId)
                .collect(Collectors.toCollection(HashSet::new));

        List<ApprovedStudentId> toInsert = new ArrayList<>();
        int skipped = 0;

        for (String batch : batches) {
            for (int serial = startSerial; serial <= endSerial; serial++) {
                String id = batch + "-" + deptCode + "-" + String.format("%03d", serial);
                if (existing.contains(id)) {
                    skipped++;
                    continue;
                }
                toInsert.add(new ApprovedStudentId(id));
                existing.add(id);
            }
        }

        approvedStudentIdRepository.saveAll(toInsert);

        redirectAttributes.addFlashAttribute("bulkMessage",
                "Added " + toInsert.size() + " new ID" + (toInsert.size() == 1 ? "" : "s")
                        + (skipped > 0 ? ", skipped " + skipped + " already on the list" : "") + ".");
        return "redirect:/admin/approved-ids";
    }

    /** Undo helper for a bulk-add mistake: removes every approved ID starting with the given prefix (e.g. "221-15-" or a whole batch "221-"). */
    @PostMapping("/bulk-remove")
    public String bulkRemove(@RequestParam String prefix, RedirectAttributes redirectAttributes) {
        prefix = prefix.trim();
        if (prefix.isEmpty()) {
            return "redirect:/admin/approved-ids";
        }
        List<ApprovedStudentId> matches = approvedStudentIdRepository.findByStudentIdStartingWith(prefix);
        approvedStudentIdRepository.deleteAll(matches);
        redirectAttributes.addFlashAttribute("bulkMessage",
                "Removed " + matches.size() + " ID" + (matches.size() == 1 ? "" : "s") + " starting with \"" + prefix + "\".");
        return "redirect:/admin/approved-ids";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id) {
        approvedStudentIdRepository.deleteById(id);
        return "redirect:/admin/approved-ids";
    }
}
