package com.university.unibus.seed;

import com.university.unibus.model.*;
import com.university.unibus.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalTime;

/**
 * Seeds the database with the real DIU Bus Tracking System route/bus/shift setup on first run.
 * Only runs if the routes table is empty, so it never overwrites data the
 * Admin has already edited through the dashboard (Phase 4 onward).
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final RouteRepository routeRepository;
    private final BusStopRepository busStopRepository;
    private final ShiftRepository shiftRepository;
    private final BusRepository busRepository;
    private final DriverRepository driverRepository;
    private final AdminRepository adminRepository;
    private final StudentRepository studentRepository;
    private final ApprovedStudentIdRepository approvedStudentIdRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(RouteRepository routeRepository,
                       BusStopRepository busStopRepository,
                       ShiftRepository shiftRepository,
                       BusRepository busRepository,
                       DriverRepository driverRepository,
                       AdminRepository adminRepository,
                       StudentRepository studentRepository,
                       ApprovedStudentIdRepository approvedStudentIdRepository,
                       PasswordEncoder passwordEncoder) {
        this.routeRepository = routeRepository;
        this.busStopRepository = busStopRepository;
        this.shiftRepository = shiftRepository;
        this.busRepository = busRepository;
        this.driverRepository = driverRepository;
        this.adminRepository = adminRepository;
        this.studentRepository = studentRepository;
        this.approvedStudentIdRepository = approvedStudentIdRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (routeRepository.count() > 0) {
            return; // already seeded
        }

        // ---- Shifts ----
        Shift morning7 = shiftRepository.save(new Shift("7:00 AM Shift", LocalTime.of(7, 0)));
        Shift morning10 = shiftRepository.save(new Shift("10:00 AM Shift", LocalTime.of(10, 0)));

        // ---- Route 1: Daffodil -> Khagan -> Akran Bazar -> Birulia -> Mirpur ----
        Route route1 = routeRepository.save(new Route("Route 1", "Daffodil - Khagan - Akran Bazar - Birulia - Mirpur"));
        saveStops(route1,
                stop("Daffodil", 23.8769, 90.3202),
                stop("Khagan", 23.8720, 90.3180),
                stop("Akran Bazar", 23.8630, 90.3160),
                stop("Birulia", 23.8533, 90.3140),
                stop("Mirpur", 23.8041, 90.3679));

        // ---- Route 2: Daffodil -> Khagan -> C&B Bus Stand -> Savar ----
        Route route2 = routeRepository.save(new Route("Route 2", "Daffodil - Khagan - C&B Bus Stand - Savar"));
        saveStops(route2,
                stop("Daffodil", 23.8769, 90.3202),
                stop("Khagan", 23.8720, 90.3180),
                stop("C&B Bus Stand", 23.8600, 90.2750),
                stop("Savar", 23.8583, 90.2667));

        // ---- Route 3: Daffodil -> Charabag Bazar -> Ashulia -> Kamarpara Bus Stand -> Tongi ----
        Route route3 = routeRepository.save(new Route("Route 3", "Daffodil - Charabag Bazar - Ashulia - Kamarpara Bus Stand - Tongi"));
        saveStops(route3,
                stop("Daffodil", 23.8769, 90.3202),
                stop("Charabag Bazar", 23.8830, 90.3260),
                stop("Ashulia", 23.8973, 90.3231),
                stop("Kamarpara Bus Stand", 23.8914, 90.3886),
                stop("Tongi", 23.8908, 90.4023));

        // ---- Drivers (Phase 5: real login now works — phone number + this password) ----
        String driverPassword = passwordEncoder.encode("changeme");
        // Driver One uses the test phone/password requested for easy demo login.
        Driver d1 = driverRepository.save(new Driver("Driver One", "01700000000", passwordEncoder.encode("222222")));
        Driver d2 = driverRepository.save(new Driver("Driver Two", "01700000002", driverPassword));
        Driver d3 = driverRepository.save(new Driver("Driver Three", "01700000003", driverPassword));
        Driver d4 = driverRepository.save(new Driver("Driver Four", "01700000004", driverPassword));
        Driver d5 = driverRepository.save(new Driver("Driver Five", "01700000005", driverPassword));
        Driver d6 = driverRepository.save(new Driver("Driver Six", "01700000006", driverPassword));

        // ---- Buses: 2 per route, one on each shift ----
        saveBus("Bus-01", route1, morning7, d1);
        saveBus("Bus-02", route1, morning10, d2);
        saveBus("Bus-03", route2, morning7, d3);
        saveBus("Bus-04", route2, morning10, d4);
        saveBus("Bus-05", route3, morning10, d5);
        saveBus("Bus-06", route3, morning7, d6);

        // ---- Default admin (CHANGE THIS password before going live — or use the
        //      in-app "Change Password" screen at /admin/settings once logged in) ----
        adminRepository.save(new Admin("251-15-761",
                passwordEncoder.encode("222222"),
                passwordEncoder.encode("181760")));

        // ---- Demo: one pre-registered student so you can log in immediately ----
        // NOTE: this Student ID intentionally matches the Admin ID above (251-15-761).
        // That's fine — students and admins are separate tables/login pages, so there's
        // no clash: /login checks the students table, /admin/login checks the admins table.
        Student demoStudent = new Student("251-15-761", "Approved Test Student",
                passwordEncoder.encode("222222"));
        demoStudent.setApproved(true);
        studentRepository.save(demoStudent);
        approvedStudentIdRepository.save(newUsedId("251-15-761"));

        // ---- Demo: Student IDs on the approved whitelist but NOT registered yet ----
        // Try registering with one of these at /register to see the whitelist in action.
        approvedStudentIdRepository.save(new ApprovedStudentId("TEST-002"));
        approvedStudentIdRepository.save(new ApprovedStudentId("TEST-003"));
        approvedStudentIdRepository.save(new ApprovedStudentId("221-15-1234"));
    }

    private ApprovedStudentId newUsedId(String studentId) {
        ApprovedStudentId approvedId = new ApprovedStudentId(studentId);
        approvedId.setUsed(true);
        return approvedId;
    }

    private void saveStops(Route route, StopSeed... stops) {
        int order = 1;
        for (StopSeed s : stops) {
            BusStop stop = new BusStop(s.name, order++, route);
            stop.setLatitude(s.lat);
            stop.setLongitude(s.lng);
            busStopRepository.save(stop);
        }
    }

    // Small helper so the route lists above read as "name, lat, lng" instead of parallel arrays.
    // NOTE: Daffodil/Ashulia/Birulia/Kamarpara/Tongi/Savar/Mirpur coordinates are real published
    // locations. Khagan/Akran Bazar/C&B Bus Stand/Charabag Bazar are small local spots without a
    // reliable public geocode, so those are ROUGH placeholders along the route path — fix them
    // precisely from the Admin Panel (Routes & Stops -> Edit Stop -> drop a pin from Google Maps)
    // once you know the exact spot.
    private StopSeed stop(String name, double lat, double lng) {
        return new StopSeed(name, lat, lng);
    }

    private record StopSeed(String name, double lat, double lng) {
    }

    private void saveBus(String busNumber, Route route, Shift shift, Driver driver) {
        Bus bus = new Bus(busNumber, route, shift);
        bus.setDriver(driver);
        busRepository.save(bus);
    }
}
