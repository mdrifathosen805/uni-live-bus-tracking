package com.university.unibus.controller;

import com.university.unibus.model.Admin;
import com.university.unibus.repository.AdminRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

/**
 * Admin login is handled by hand (not Spring Security's built-in formLogin)
 * because it needs THREE fields — Admin ID, password, AND a secret code —
 * while formLogin only supports two. We check all three ourselves, then
 * hand a fully-formed authentication over to Spring Security so the rest
 * of the app (session handling, /admin/** access rules, logout) works
 * exactly the same as it does for students.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminController(AdminRepository adminRepository, PasswordEncoder passwordEncoder) {
        this.adminRepository = adminRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "admin-login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String adminId,
                         @RequestParam String password,
                         @RequestParam String secretCode,
                         HttpServletRequest request) {

        Optional<Admin> adminOpt = adminRepository.findByAdminId(adminId);

        boolean passwordOk = adminOpt.isPresent() && passwordEncoder.matches(password, adminOpt.get().getPassword());
        boolean secretCodeOk = adminOpt.isPresent() && passwordEncoder.matches(secretCode, adminOpt.get().getSecretCode());

        if (adminOpt.isEmpty() || !passwordOk || !secretCodeOk) {
            // Deliberately vague — we don't say which of the three fields was wrong,
            // so a random visitor can't use the error message to guess admin credentials.
            return "redirect:/admin/login?error";
        }

        Admin admin = adminOpt.get();
        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                admin.getAdminId(), null, List.of(new SimpleGrantedAuthority("ROLE_ADMIN")));

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authToken);
        SecurityContextHolder.setContext(context);
        // Persist into the session so this authentication survives across requests
        // (this is the same session attribute key Spring Security itself uses).
        request.getSession(true).setAttribute("SPRING_SECURITY_CONTEXT", context);

        return "redirect:/admin/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model) {
        model.addAttribute("adminId", principal.getName());
        return "admin-dashboard";
    }

    @GetMapping("/settings")
    public String settingsPage(Model model) {
        return "admin/change-password";
    }

    @PostMapping("/settings/password")
    public String changePassword(@RequestParam String currentPassword,
                                  @RequestParam String newPassword,
                                  @RequestParam String confirmPassword,
                                  Principal principal,
                                  Model model) {

        Admin admin = adminRepository.findByAdminId(principal.getName())
                .orElseThrow(() -> new IllegalStateException("Logged-in admin not found: " + principal.getName()));

        if (!passwordEncoder.matches(currentPassword, admin.getPassword())) {
            model.addAttribute("error", "Current password is incorrect.");
            return "admin/change-password";
        }
        if (newPassword.length() < 6) {
            model.addAttribute("error", "New password must be at least 6 characters.");
            return "admin/change-password";
        }
        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("error", "New password and confirmation do not match.");
            return "admin/change-password";
        }

        admin.setPassword(passwordEncoder.encode(newPassword));
        adminRepository.save(admin);

        model.addAttribute("success", "Password updated. Use your new password next time you log in.");
        return "admin/change-password";
    }
}
