package com.university.unibus.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * IMPORTANT - why this bean must be explicit:
     *
     * Two classes in this project implement UserDetailsService:
     * StudentUserDetailsService and DriverUserDetailsService (the latter is
     * currently unused for actual login - see its class comment - but it's
     * still a registered @Service bean). When Spring Security finds more
     * than one UserDetailsService bean and no AuthenticationManager is
     * defined explicitly, its automatic setup silently gives up and wires
     * NO authentication provider at all. The practical symptom: every
     * student login attempt fails with "Login failed", even with the exact
     * right Student ID and password, because nothing is actually checking
     * them. Defining the AuthenticationManager here removes the ambiguity:
     * student login is always checked against StudentUserDetailsService.
     */
    @Bean
    public AuthenticationManager authenticationManager(StudentUserDetailsService studentUserDetailsService,
                                                         PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(studentUserDetailsService);
        provider.setPasswordEncoder(passwordEncoder);
        return new ProviderManager(provider);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        // Public pages: home, overview, registration, login, static assets, SEO files
                        .requestMatchers("/", "/overview", "/css/**", "/register", "/register/verify", "/register/resend-code", "/login", "/forgot-password", "/reset-password", "/test-email", "/mail-setup", "/admin/login", "/driver/login", "/driver/register", "/robots.txt", "/sitemap.xml").permitAll()
                        // H2 console stays open for now during development (Phase 1-2 only)
                        .requestMatchers("/h2-console/**").permitAll()
                        // Admin area requires the ROLE_ADMIN authority (see AdminController)
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        // Driver area and the GPS-ping API require ROLE_DRIVER (see DriverController)
                        .requestMatchers("/driver/**", "/api/location/**").hasRole("DRIVER")
                        // Everything else (student dashboard) requires login
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .usernameParameter("studentId")
                        .passwordParameter("password")
                        .defaultSuccessUrl("/dashboard", true)
                        .failureUrl("/login?error")
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                        .permitAll()
                )
                // H2 console runs in a frame and posts without a CSRF token — exempt it.
                .csrf(csrf -> csrf.ignoringRequestMatchers("/h2-console/**"))
                .headers(headers -> headers.frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin));

        return http.build();
    }
}
