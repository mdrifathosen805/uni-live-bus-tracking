package com.university.unibus.repository;

import com.university.unibus.model.Bus;
import com.university.unibus.model.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BusRepository extends JpaRepository<Bus, Long> {
    Optional<Bus> findByBusNumber(String busNumber);
    Optional<Bus> findByDriver(Driver driver);
}
