package com.university.unibus.controller;

import com.university.unibus.dto.BusStatusView;
import com.university.unibus.model.Bus;
import com.university.unibus.model.BusStop;
import com.university.unibus.model.Student;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.BusStopRepository;
import com.university.unibus.repository.RouteRepository;
import com.university.unibus.repository.StudentRepository;
import com.university.unibus.service.BusStatusService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
public class AuthController {

    private final StudentRepository studentRepository;
    private final BusStopRepository busStopRepository;
    private final BusRepository busRepository;
    private final RouteRepository routeRepository;
    private final BusStatusService busStatusService;

    public AuthController(StudentRepository studentRepository, BusStopRepository busStopRepository,
                           BusRepository busRepository, RouteRepository routeRepository,
                           BusStatusService busStatusService) {
        this.studentRepository = studentRepository;
        this.busStopRepository = busStopRepository;
        this.busRepository = busRepository;
        this.routeRepository = routeRepository;
        this.busStatusService = busStatusService;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model) {
        // principal.getName() is the Student ID used to log in (see StudentUserDetailsService)
        Student student = studentRepository.findByStudentId(principal.getName())
                .orElseThrow(() -> new IllegalStateException("Logged-in student not found: " + principal.getName()));
        model.addAttribute("student", student);
        model.addAttribute("routes", routeRepository.findAllWithStops());

        if (student.getPreferredStop() != null) {
            BusStop stop = student.getPreferredStop();
            List<BusStatusView> statuses = busRepository.findAll().stream()
                    .filter(b -> b.isActive() && b.getRoute().getId().equals(stop.getRoute().getId()))
                    .map(b -> busStatusService.statusForStop(b, stop))
                    .toList();
            model.addAttribute("busStatuses", statuses);
        }

        return "dashboard";
    }

    @PostMapping("/dashboard/set-stop")
    public String setStop(@RequestParam Long stopId, Principal principal) {
        Student student = studentRepository.findByStudentId(principal.getName())
                .orElseThrow(() -> new IllegalStateException("Logged-in student not found: " + principal.getName()));
        busStopRepository.findById(stopId).ifPresent(student::setPreferredStop);
        studentRepository.save(student);
        return "redirect:/dashboard";
    }
}
