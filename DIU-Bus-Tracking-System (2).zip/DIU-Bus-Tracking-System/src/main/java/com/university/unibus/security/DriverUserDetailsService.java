package com.university.unibus.security;

import com.university.unibus.model.Driver;
import com.university.unibus.repository.DriverRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Authenticates drivers by their phone number. A driver disabled by the
 * Admin (Driver.active = false) is rejected the same way a blocked student
 * is — before the password is even checked.
 *
 * Not used directly by a Spring Security formLogin filter chain (that slot
 * is already taken by the student login) — DriverController checks
 * credentials by hand the same way AdminController does. This class exists
 * so that logic has one clean, reusable place, and so any future switch to
 * a real formLogin chain for drivers is a small change.
 */
@Service
public class DriverUserDetailsService implements UserDetailsService {

    private final DriverRepository driverRepository;

    public DriverUserDetailsService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String phone) throws UsernameNotFoundException {
        Driver driver = driverRepository.findByPhone(phone)
                .orElseThrow(() -> new UsernameNotFoundException("No driver account found for phone: " + phone));

        return User.builder()
                .username(driver.getPhone())
                .password(driver.getPassword())
                .authorities("ROLE_DRIVER")
                .disabled(!driver.isActive())
                .build();
    }
}
