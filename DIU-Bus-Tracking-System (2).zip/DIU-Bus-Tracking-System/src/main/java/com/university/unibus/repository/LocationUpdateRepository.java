package com.university.unibus.repository;

import com.university.unibus.model.Bus;
import com.university.unibus.model.LocationUpdate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LocationUpdateRepository extends JpaRepository<LocationUpdate, Long> {
    List<LocationUpdate> findByBusOrderByRecordedAtDesc(Bus bus);
}
