package com.university.unibus.repository;

import com.university.unibus.model.Bus;
import com.university.unibus.model.BusStop;
import com.university.unibus.model.StopEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StopEventRepository extends JpaRepository<StopEvent, Long> {
    Optional<StopEvent> findTopByBusAndStopOrderByArrivedAtDesc(Bus bus, BusStop stop);
}
