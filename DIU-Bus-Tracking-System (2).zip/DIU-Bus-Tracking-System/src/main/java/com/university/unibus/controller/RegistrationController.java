package com.university.unibus.controller;

import com.university.unibus.dto.StudentRegistrationForm;
import com.university.unibus.model.ApprovedStudentId;
import com.university.unibus.model.PendingStudentRegistration;
import com.university.unibus.model.Student;
import com.university.unibus.repository.ApprovedStudentIdRepository;
import com.university.unibus.repository.PendingStudentRegistrationRepository;
import com.university.unibus.repository.StudentRepository;
import com.university.unibus.service.EmailService;
import jakarta.validation.Valid;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Two-step registration:
 *   1. POST /register            -> validate form, email a 6-digit code to their Gmail,
 *                                    save the details (password already hashed) as "pending"
 *   2. GET  /register/verify     -> enter the code
 *   3. POST /register/verify     -> if the code matches, actually create the Student account
 *
 * Nothing is added to the "students" table until step 3 succeeds, so an
 * unverified/incorrect email can never become a login-able account.
 */
@Controller
public class RegistrationController {

    private static final int CODE_VALID_MINUTES = 10;
    private static final int MAX_ATTEMPTS = 5;

    private final StudentRepository studentRepository;
    private final ApprovedStudentIdRepository approvedStudentIdRepository;
    private final PendingStudentRegistrationRepository pendingRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final SecureRandom random = new SecureRandom();

    public RegistrationController(StudentRepository studentRepository,
                                   ApprovedStudentIdRepository approvedStudentIdRepository,
                                   PendingStudentRegistrationRepository pendingRepository,
                                   PasswordEncoder passwordEncoder,
                                   EmailService emailService) {
        this.studentRepository = studentRepository;
        this.approvedStudentIdRepository = approvedStudentIdRepository;
        this.pendingRepository = pendingRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    @GetMapping("/register")
    public String showForm(Model model) {
        model.addAttribute("form", new StudentRegistrationForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("form") StudentRegistrationForm form, BindingResult result,
                            RedirectAttributes redirectAttributes) {
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword", "mismatch", "Passwords do not match");
        }

        if (studentRepository.findByStudentId(form.getStudentId()).isPresent()) {
            result.rejectValue("studentId", "duplicate", "An account already exists for this Student ID");
        }

        ApprovedStudentId approvedId = null;
        if (!result.hasFieldErrors("studentId")) {
            approvedId = approvedStudentIdRepository.findByStudentId(form.getStudentId()).orElse(null);
            if (approvedId == null) {
                result.rejectValue("studentId", "notApproved",
                        "This Student ID is not recognized by the university records. Contact the Admin office.");
            }
        }

        if (result.hasErrors()) {
            return "register";
        }

        // Replace any earlier unfinished attempt for this Student ID with a fresh one.
        pendingRepository.findByStudentId(form.getStudentId()).ifPresent(pendingRepository::delete);

        PendingStudentRegistration pending = new PendingStudentRegistration();
        pending.setStudentId(form.getStudentId());
        pending.setName(form.getName());
        pending.setEmail(form.getEmail());
        pending.setPasswordHash(passwordEncoder.encode(form.getPassword()));
        pending.setCode(generateCode());
        pending.setExpiresAt(LocalDateTime.now().plusMinutes(CODE_VALID_MINUTES));
        pendingRepository.save(pending);

        EmailService.SendResult sendResult = emailService.sendVerificationCode(
                pending.getEmail(), pending.getName(), pending.getCode());
        addFallbackIfNeeded(redirectAttributes, sendResult, pending.getCode());

        return "redirect:/register/verify?studentId=" + form.getStudentId();
    }

    @GetMapping("/register/verify")
    public String verifyForm(@RequestParam String studentId, Model model) {
        Optional<PendingStudentRegistration> pendingOpt = pendingRepository.findByStudentId(studentId);
        if (pendingOpt.isEmpty()) {
            return "redirect:/register";
        }
        model.addAttribute("studentId", studentId);
        model.addAttribute("email", pendingOpt.get().getEmail());
        return "register-verify";
    }

    @PostMapping("/register/verify")
    public String verifySubmit(@RequestParam String studentId, @RequestParam String code, Model model) {
        Optional<PendingStudentRegistration> pendingOpt = pendingRepository.findByStudentId(studentId);
        if (pendingOpt.isEmpty()) {
            return "redirect:/register";
        }
        PendingStudentRegistration pending = pendingOpt.get();

        if (pending.isExpired()) {
            pendingRepository.delete(pending);
            model.addAttribute("error", "This code has expired. Please register again.");
            model.addAttribute("expired", true);
            return "register-verify";
        }

        if (pending.getAttempts() >= MAX_ATTEMPTS) {
            pendingRepository.delete(pending);
            model.addAttribute("error", "Too many incorrect attempts. Please register again.");
            model.addAttribute("expired", true);
            return "register-verify";
        }

        if (!pending.getCode().equals(code.trim())) {
            pending.setAttempts(pending.getAttempts() + 1);
            pendingRepository.save(pending);
            model.addAttribute("studentId", studentId);
            model.addAttribute("email", pending.getEmail());
            model.addAttribute("error", "Incorrect code. Please check your email and try again.");
            return "register-verify";
        }

        // Code correct -> actually create the account now.
        Student student = new Student(pending.getStudentId(), pending.getName(), pending.getPasswordHash());
        student.setEmail(pending.getEmail());
        student.setApproved(true);
        student.setBlocked(false);
        studentRepository.save(student);

        approvedStudentIdRepository.findByStudentId(pending.getStudentId()).ifPresent(a -> {
            a.setUsed(true);
            approvedStudentIdRepository.save(a);
        });

        pendingRepository.delete(pending);

        return "redirect:/login?registered";
    }

    @PostMapping("/register/resend-code")
    public String resendCode(@RequestParam String studentId, RedirectAttributes redirectAttributes) {
        pendingRepository.findByStudentId(studentId).ifPresent(pending -> {
            pending.setCode(generateCode());
            pending.setExpiresAt(LocalDateTime.now().plusMinutes(CODE_VALID_MINUTES));
            pending.setAttempts(0);
            pendingRepository.save(pending);
            EmailService.SendResult sendResult = emailService.sendVerificationCode(
                    pending.getEmail(), pending.getName(), pending.getCode());
            addFallbackIfNeeded(redirectAttributes, sendResult, pending.getCode());
        });
        return "redirect:/register/verify?studentId=" + studentId;
    }

    /** If the real email failed to send, show the code right on the page instead - registration should never get stuck just because Gmail didn't cooperate. */
    private void addFallbackIfNeeded(RedirectAttributes redirectAttributes, EmailService.SendResult sendResult, String code) {
        if (!sendResult.success()) {
            redirectAttributes.addFlashAttribute("mailFailed", true);
            redirectAttributes.addFlashAttribute("devCode", code);
            redirectAttributes.addFlashAttribute("mailErrorDetail", sendResult.detail());
        }
    }

    private String generateCode() {
        return String.format("%06d", random.nextInt(1_000_000));
    }
}
