package com.university.unibus.dto;

import java.time.LocalDateTime;

/** Read-only view of a bus's status relative to one specific stop — this is
 *  what the student dashboard's "Your Stop" card is built from. Not a JPA entity. */
public class BusStatusView {

    private Long busId;
    private String busNumber;
    private String routeName;
    private String shiftName;
    private boolean tripActive;

    private String currentStopName;
    private String nextStopName;
    private Double currentSpeed;
    private LocalDateTime lastUpdated;

    private String status;       // NOT_STARTED, ON_THE_WAY, AT_STOP, PASSED, ENDED
    private String statusLabel;  // human-readable
    private Integer etaMinutes;
    private LocalDateTime passedAt;

    public Long getBusId() { return busId; }
    public void setBusId(Long busId) { this.busId = busId; }

    public String getBusNumber() { return busNumber; }
    public void setBusNumber(String busNumber) { this.busNumber = busNumber; }

    public String getRouteName() { return routeName; }
    public void setRouteName(String routeName) { this.routeName = routeName; }

    public String getShiftName() { return shiftName; }
    public void setShiftName(String shiftName) { this.shiftName = shiftName; }

    public boolean isTripActive() { return tripActive; }
    public void setTripActive(boolean tripActive) { this.tripActive = tripActive; }

    public String getCurrentStopName() { return currentStopName; }
    public void setCurrentStopName(String currentStopName) { this.currentStopName = currentStopName; }

    public String getNextStopName() { return nextStopName; }
    public void setNextStopName(String nextStopName) { this.nextStopName = nextStopName; }

    public Double getCurrentSpeed() { return currentSpeed; }
    public void setCurrentSpeed(Double currentSpeed) { this.currentSpeed = currentSpeed; }

    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getStatusLabel() { return statusLabel; }
    public void setStatusLabel(String statusLabel) { this.statusLabel = statusLabel; }

    public Integer getEtaMinutes() { return etaMinutes; }
    public void setEtaMinutes(Integer etaMinutes) { this.etaMinutes = etaMinutes; }

    public LocalDateTime getPassedAt() { return passedAt; }
    public void setPassedAt(LocalDateTime passedAt) { this.passedAt = passedAt; }

    /** CSS class for the status badge, computed here (in Java) instead of with a
     *  fragile nested Thymeleaf ternary in the template. */
    public String getStatusCssClass() {
        if (status == null) return "not-started";
        return switch (status) {
            case "ON_THE_WAY" -> "on-the-way";
            case "AT_STOP" -> "at-stop";
            case "PASSED" -> "passed-status";
            default -> "not-started";
        };
    }
}
