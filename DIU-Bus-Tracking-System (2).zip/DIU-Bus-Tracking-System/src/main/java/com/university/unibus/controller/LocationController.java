package com.university.unibus.controller;

import com.university.unibus.dto.LocationUpdateRequest;
import com.university.unibus.model.Bus;
import com.university.unibus.model.Driver;
import com.university.unibus.model.LocationUpdate;
import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.DriverRepository;
import com.university.unibus.repository.LocationUpdateRepository;
import com.university.unibus.service.BusStatusService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Phase 6-7: receives GPS pings from a driver's phone (sent by the JS in
 * driver-dashboard.html) and stores them. This keeps everything in the same
 * relational database rather than adding a separate realtime-DB service
 * (Firebase/etc) — cheaper and simpler to run, and plenty fast enough for
 * 6 buses polling every ~10-15 seconds. The student-facing map (Phase 8)
 * will just poll Bus.currentLatitude/Longitude the same way.
 */
@RestController
@RequestMapping("/api/location")
public class LocationController {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("hh:mm:ss a");

    private final DriverRepository driverRepository;
    private final BusRepository busRepository;
    private final LocationUpdateRepository locationUpdateRepository;
    private final BusStatusService busStatusService;

    public LocationController(DriverRepository driverRepository, BusRepository busRepository,
                               LocationUpdateRepository locationUpdateRepository, BusStatusService busStatusService) {
        this.driverRepository = driverRepository;
        this.busRepository = busRepository;
        this.locationUpdateRepository = locationUpdateRepository;
        this.busStatusService = busStatusService;
    }

    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> update(@Valid @RequestBody LocationUpdateRequest request,
                                                        Principal principal) {
        // principal is guaranteed non-null and ROLE_DRIVER here — enforced by SecurityConfig.
        Driver driver = driverRepository.findByPhone(principal.getName()).orElse(null);
        if (driver == null) {
            return ResponseEntity.status(401).body(error("Driver account not found."));
        }

        Optional<Bus> busOpt = busRepository.findById(request.getBusId());
        if (busOpt.isEmpty()) {
            return ResponseEntity.status(404).body(error("Bus not found."));
        }

        Bus bus = busOpt.get();

        // Ownership check: a driver can only push location for the bus assigned to them,
        // even if they tamper with the busId in the request.
        if (bus.getDriver() == null || !bus.getDriver().getId().equals(driver.getId())) {
            return ResponseEntity.status(403).body(error("This bus is not assigned to you."));
        }

        if (!bus.isTripActive()) {
            return ResponseEntity.status(409).body(error("Trip is not active. Press Start Trip first."));
        }

        LocationUpdate update = new LocationUpdate(bus, request.getLatitude(), request.getLongitude(), request.getSpeed());
        locationUpdateRepository.save(update);

        LocalDateTime now = LocalDateTime.now();
        bus.setCurrentLatitude(request.getLatitude());
        bus.setCurrentLongitude(request.getLongitude());
        bus.setCurrentSpeed(request.getSpeed());
        bus.setLastUpdated(now);
        busStatusService.onLocationUpdate(bus, request.getLatitude(), request.getLongitude());
        busRepository.save(bus);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", "ok");
        body.put("lastUpdated", now.format(TIME_FORMAT));
        body.put("currentStopName", bus.getCurrentStopName());
        return ResponseEntity.ok(body);
    }

    private Map<String, Object> error(String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", "error");
        body.put("message", message);
        return body;
    }
}
