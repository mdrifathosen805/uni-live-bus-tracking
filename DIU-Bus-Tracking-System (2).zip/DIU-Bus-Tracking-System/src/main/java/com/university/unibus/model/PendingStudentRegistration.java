package com.university.unibus.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Holds a student's registration details (with password already hashed)
 * while we wait for them to confirm the verification code we emailed to
 * their Gmail. Nothing is created in the "students" table until the code
 * is confirmed in RegistrationController.
 */
@Entity
@Table(name = "pending_student_registrations")
public class PendingStudentRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String studentId;

    private String name;

    private String email;

    private String passwordHash;

    private String code; // 6-digit verification code

    private LocalDateTime expiresAt;

    private int attempts = 0; // wrong-code attempts, to block brute-forcing a 6-digit code

    public PendingStudentRegistration() {
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
    public int getAttempts() { return attempts; }
    public void setAttempts(int attempts) { this.attempts = attempts; }
}
