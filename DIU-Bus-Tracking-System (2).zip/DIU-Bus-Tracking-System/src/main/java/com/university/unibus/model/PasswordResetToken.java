package com.university.unibus.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * A one-time-use token emailed to a student so they can set a new password
 * without knowing the old one. Created by PasswordResetController when the
 * student submits the "Forgot password" form, and consumed (marked used)
 * when they actually reset their password.
 */
@Entity
@Table(name = "password_reset_tokens")
public class PasswordResetToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String token;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    private LocalDateTime expiresAt;

    private boolean used = false;

    public PasswordResetToken() {
    }

    public PasswordResetToken(String token, Student student, LocalDateTime expiresAt) {
        this.token = token;
        this.student = student;
        this.expiresAt = expiresAt;
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
    public boolean isUsed() { return used; }
    public void setUsed(boolean used) { this.used = used; }
}
