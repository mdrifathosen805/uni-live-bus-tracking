package com.university.unibus.controller;

import com.university.unibus.service.EmailService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * A tiny, no-terminal-needed page to test the Gmail connection directly from
 * the browser: open /test-email, type an email address you can check, click
 * Send, and this page shows you EXACTLY what happened (success, or the real
 * error from Gmail) - no need to dig through NetBeans' console output.
 *
 * SECURITY NOTE: this page does not require login so it's easy to use while
 * you're getting Gmail working. Once emails are sending correctly, either
 * delete this file or remove "/test-email" from SecurityConfig's permitAll
 * list so strangers can't use your Gmail account to spam themselves a test.
 */
@Controller
public class DebugMailController {

    private final EmailService emailService;

    public DebugMailController(EmailService emailService) {
        this.emailService = emailService;
    }

    @GetMapping("/test-email")
    public String form(Model model) {
        model.addAttribute("mailEnabled", emailService.isMailEnabled());
        model.addAttribute("fromAddress", emailService.getFromAddress());
        return "test-email";
    }

    @PostMapping("/test-email")
    public String send(@RequestParam String to, Model model) {
        model.addAttribute("mailEnabled", emailService.isMailEnabled());
        model.addAttribute("fromAddress", emailService.getFromAddress());
        model.addAttribute("to", to);

        EmailService.SendResult result = emailService.sendTestEmail(to);
        model.addAttribute("success", result.success());
        model.addAttribute("detail", result.detail());
        return "test-email";
    }
}
