package com.university.unibus.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Recorded the moment a bus is detected as having arrived at a stop (its GPS
 * came within arrival range of that stop's coordinates). This is how we can
 * tell a student "Bus passed your stop, passed at: 10:31 AM" instead of just
 * "passed" with no time.
 */
@Entity
@Table(name = "stop_events")
public class StopEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "bus_id", nullable = false)
    private Bus bus;

    @ManyToOne
    @JoinColumn(name = "stop_id", nullable = false)
    private BusStop stop;

    private LocalDateTime arrivedAt = LocalDateTime.now();

    public StopEvent() {
    }

    public StopEvent(Bus bus, BusStop stop) {
        this.bus = bus;
        this.stop = stop;
        this.arrivedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }

    public BusStop getStop() {
        return stop;
    }

    public void setStop(BusStop stop) {
        this.stop = stop;
    }

    public LocalDateTime getArrivedAt() {
        return arrivedAt;
    }

    public void setArrivedAt(LocalDateTime arrivedAt) {
        this.arrivedAt = arrivedAt;
    }
}
