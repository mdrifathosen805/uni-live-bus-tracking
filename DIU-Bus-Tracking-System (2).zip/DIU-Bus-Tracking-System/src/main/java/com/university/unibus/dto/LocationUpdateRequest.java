package com.university.unibus.dto;

import jakarta.validation.constraints.NotNull;

/** Body sent by the driver dashboard's JS every time it reads a GPS fix. */
public class LocationUpdateRequest {

    @NotNull
    private Long busId;

    @NotNull
    private Double latitude;

    @NotNull
    private Double longitude;

    // km/h — optional, not every browser Geolocation fix includes speed
    private Double speed;

    public Long getBusId() {
        return busId;
    }

    public void setBusId(Long busId) {
        this.busId = busId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getSpeed() {
        return speed;
    }

    public void setSpeed(Double speed) {
        this.speed = speed;
    }
}
