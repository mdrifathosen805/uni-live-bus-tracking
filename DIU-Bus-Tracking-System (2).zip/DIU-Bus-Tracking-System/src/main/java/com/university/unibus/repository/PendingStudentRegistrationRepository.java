package com.university.unibus.repository;

import com.university.unibus.model.PendingStudentRegistration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PendingStudentRegistrationRepository extends JpaRepository<PendingStudentRegistration, Long> {
    Optional<PendingStudentRegistration> findByStudentId(String studentId);
}
