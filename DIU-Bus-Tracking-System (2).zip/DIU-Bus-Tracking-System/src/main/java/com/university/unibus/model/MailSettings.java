package com.university.unibus.model;

import jakarta.persistence.*;

/**
 * Lets the Gmail sender address + App Password be set from a page in the
 * browser (/mail-setup) instead of hand-editing application.properties.
 * There is always at most one row (id = 1).
 */
@Entity
@Table(name = "mail_settings")
public class MailSettings {

    @Id
    private Long id = 1L;

    private String gmailUsername;

    private String gmailAppPassword;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getGmailUsername() { return gmailUsername; }
    public void setGmailUsername(String gmailUsername) { this.gmailUsername = gmailUsername; }
    public String getGmailAppPassword() { return gmailAppPassword; }
    public void setGmailAppPassword(String gmailAppPassword) { this.gmailAppPassword = gmailAppPassword; }
}
