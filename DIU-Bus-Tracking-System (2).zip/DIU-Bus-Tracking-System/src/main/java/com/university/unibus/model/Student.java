package com.university.unibus.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Student ID is required")
    @Column(unique = true)
    private String studentId; // university-issued ID, must match the approved list

    @NotBlank(message = "Name is required")
    private String name;

    private String email; // optional, per project rules

    // NOTE: plain text for now — real password hashing (BCrypt) is added in Phase 2.
    private String password;

    private boolean approved = false;
    private boolean blocked = false;

    @ManyToOne
    @JoinColumn(name = "preferred_stop_id")
    private BusStop preferredStop; // nullable — set once the student picks their stop

    public Student() {
    }

    public Student(String studentId, String name, String password) {
        this.studentId = studentId;
        this.name = name;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public BusStop getPreferredStop() {
        return preferredStop;
    }

    public void setPreferredStop(BusStop preferredStop) {
        this.preferredStop = preferredStop;
    }
}
