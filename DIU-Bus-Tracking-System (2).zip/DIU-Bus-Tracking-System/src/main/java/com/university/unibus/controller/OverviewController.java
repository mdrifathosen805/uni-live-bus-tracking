package com.university.unibus.controller;

import com.university.unibus.repository.BusRepository;
import com.university.unibus.repository.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Read-only view so we can confirm the Phase 1 domain model and seed data
 * are correct before building the real Admin/Student/Driver dashboards.
 */
@Controller
public class OverviewController {

    private final RouteRepository routeRepository;
    private final BusRepository busRepository;

    @Autowired
    public OverviewController(RouteRepository routeRepository, BusRepository busRepository) {
        this.routeRepository = routeRepository;
        this.busRepository = busRepository;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/overview")
    public String overview(Model model) {
        model.addAttribute("routes", routeRepository.findAllWithStops());
        model.addAttribute("buses", busRepository.findAll());
        return "overview";
    }
}
