package com.university.unibus.controller;

import com.university.unibus.service.EmailService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Lets you set the Gmail address + App Password from the browser - no
 * hunting through project files, no restarting the app. Saved immediately
 * to the database and used from that point on for verification codes and
 * password-reset emails.
 *
 * SECURITY NOTE: open to anyone without login, to make first-time setup as
 * easy as possible. Once your Gmail is connected and working, remove
 * "/mail-setup" from SecurityConfig's permitAll list (or delete this
 * controller + template) so strangers can't overwrite your Gmail sender.
 */
@Controller
public class MailSetupController {

    private final EmailService emailService;

    public MailSetupController(EmailService emailService) {
        this.emailService = emailService;
    }

    @GetMapping("/mail-setup")
    public String form(Model model) {
        model.addAttribute("mailEnabled", emailService.isMailEnabled());
        model.addAttribute("fromAddress", emailService.getFromAddress());
        return "mail-setup";
    }

    @PostMapping("/mail-setup")
    public String save(@RequestParam String gmailUsername, @RequestParam String gmailAppPassword, Model model) {
        emailService.saveCredentials(gmailUsername, gmailAppPassword);
        model.addAttribute("saved", true);
        model.addAttribute("mailEnabled", emailService.isMailEnabled());
        model.addAttribute("fromAddress", emailService.getFromAddress());
        return "mail-setup";
    }
}
