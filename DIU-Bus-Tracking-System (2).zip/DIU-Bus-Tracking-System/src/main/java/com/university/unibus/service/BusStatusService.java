package com.university.unibus.service;

import com.university.unibus.dto.BusStatusView;
import com.university.unibus.model.Bus;
import com.university.unibus.model.BusStop;
import com.university.unibus.model.StopEvent;
import com.university.unibus.repository.StopEventRepository;
import com.university.unibus.util.GeoUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Phase 9: turns a bus's raw GPS position into the "on the way / at your
 * stop / passed your stop, ETA X min" status a student actually cares about.
 *
 * How progress is tracked (kept intentionally simple, no external routing API):
 * - When a driver presses START TRIP, Bus.currentStopIndex is set to 0 (the
 *   bus is considered to be at the first stop of its route).
 * - On every GPS ping (see LocationController), we check whether the bus has
 *   come within ARRIVAL_RADIUS_METERS of the NEXT stop on its route. If so,
 *   currentStopIndex advances by one and a StopEvent is logged — this is what
 *   lets us show "Passed at: 10:31 AM".
 * - A given stop's status for a student is just a comparison between that
 *   stop's position in the route and the bus's currentStopIndex.
 */
@Service
public class BusStatusService {

    public static final double ARRIVAL_RADIUS_METERS = 250.0;
    public static final double DEFAULT_AVG_SPEED_KMH = 20.0;

    private final StopEventRepository stopEventRepository;

    public BusStatusService(StopEventRepository stopEventRepository) {
        this.stopEventRepository = stopEventRepository;
    }

    /** Call when a driver presses START TRIP. */
    public void onTripStart(Bus bus) {
        List<BusStop> stops = bus.getRoute().getStops();
        bus.setCurrentStopIndex(stops.isEmpty() ? null : 0);
        if (!stops.isEmpty()) {
            BusStop origin = stops.get(0);
            bus.setCurrentStopName(origin.getName());
            if (origin.getLatitude() != null && origin.getLongitude() != null) {
                bus.setCurrentLatitude(origin.getLatitude());
                bus.setCurrentLongitude(origin.getLongitude());
            }
            stopEventRepository.save(new StopEvent(bus, origin));
        }
    }

    /** Call when a driver presses END TRIP. currentStopIndex is intentionally left
     *  as-is so students can still see where the bus was when the trip ended. */
    public void onTripEnd(Bus bus) {
        // no-op for now; tripActive flag (set by caller) already controls display
    }

    /**
     * Call every time a fresh GPS ping is stored (see LocationController).
     * Advances currentStopIndex if the bus has reached the next stop.
     */
    public void onLocationUpdate(Bus bus, double lat, double lng) {
        List<BusStop> stops = bus.getRoute().getStops();
        if (stops.isEmpty() || bus.getCurrentStopIndex() == null) {
            return;
        }
        int idx = bus.getCurrentStopIndex();
        // Loop (not just a single check) in case GPS pings are sparse and the bus
        // has effectively covered more than one stop between updates.
        while (idx + 1 < stops.size()) {
            BusStop next = stops.get(idx + 1);
            if (next.getLatitude() == null || next.getLongitude() == null) break;
            double dist = GeoUtils.distanceMeters(lat, lng, next.getLatitude(), next.getLongitude());
            if (dist <= ARRIVAL_RADIUS_METERS) {
                idx++;
                bus.setCurrentStopIndex(idx);
                bus.setCurrentStopName(next.getName());
                stopEventRepository.save(new StopEvent(bus, next));
            } else {
                break;
            }
        }
    }

    /** Status of one bus relative to one specific stop (what a student cares about). */
    public BusStatusView statusForStop(Bus bus, BusStop targetStop) {
        BusStatusView view = base(bus);
        List<BusStop> stops = bus.getRoute().getStops();

        int targetIndex = -1;
        for (int i = 0; i < stops.size(); i++) {
            if (stops.get(i).getId().equals(targetStop.getId())) {
                targetIndex = i;
                break;
            }
        }

        Integer currentIndex = bus.getCurrentStopIndex();
        if (currentIndex != null && currentIndex < stops.size()) {
            view.setCurrentStopName(stops.get(currentIndex).getName());
            view.setNextStopName(currentIndex + 1 < stops.size() ? stops.get(currentIndex + 1).getName() : "End of route");
        }

        if (currentIndex == null) {
            view.setStatus("NOT_STARTED");
            view.setStatusLabel("Bus hasn't started this trip yet");
            return view;
        }

        if (targetIndex == -1) {
            view.setStatus("NOT_ON_ROUTE");
            view.setStatusLabel("This stop is not on this bus's route");
            return view;
        }

        if (targetIndex < currentIndex) {
            view.setStatus("PASSED");
            view.setStatusLabel(bus.isTripActive() ? "Bus passed your stop" : "Bus passed your stop (trip ended)");
            stopEventRepository.findTopByBusAndStopOrderByArrivedAtDesc(bus, targetStop)
                    .ifPresent(ev -> view.setPassedAt(ev.getArrivedAt()));
            return view;
        }

        if (targetIndex == currentIndex) {
            view.setStatus("AT_STOP");
            view.setStatusLabel(bus.isTripActive() ? "Bus is at your stop now" : "Bus reached your stop (trip ended)");
            return view;
        }

        // targetIndex > currentIndex: still ahead
        if (!bus.isTripActive()) {
            view.setStatus("ENDED");
            view.setStatusLabel("Trip ended before reaching your stop");
            return view;
        }

        view.setStatus("ON_THE_WAY");
        view.setStatusLabel("On the way");

        if (bus.getCurrentLatitude() != null && bus.getCurrentLongitude() != null
                && targetStop.getLatitude() != null && targetStop.getLongitude() != null) {
            double distKm = GeoUtils.distanceKm(bus.getCurrentLatitude(), bus.getCurrentLongitude(),
                    targetStop.getLatitude(), targetStop.getLongitude());
            double speed = (bus.getCurrentSpeed() != null && bus.getCurrentSpeed() > 5)
                    ? bus.getCurrentSpeed() : DEFAULT_AVG_SPEED_KMH;
            view.setEtaMinutes((int) Math.max(1, Math.round(distKm / speed * 60)));
        }
        return view;
    }

    private BusStatusView base(Bus bus) {
        BusStatusView view = new BusStatusView();
        view.setBusId(bus.getId());
        view.setBusNumber(bus.getBusNumber());
        view.setRouteName(bus.getRoute().getName());
        view.setShiftName(bus.getShift().getName());
        view.setTripActive(bus.isTripActive());
        view.setCurrentSpeed(bus.getCurrentSpeed());
        view.setLastUpdated(bus.getLastUpdated());
        return view;
    }
}
